DARLING resource pack for Minecraft Java 1.21.4
Scoreboard logo: \uE000
TAB logo: \uE001
Single-glyph square-canvas build to reduce scoreboard distortion.
